#!/bin/bash
$UPTIME = uptime
echo "The system is running + $UPTIME"
